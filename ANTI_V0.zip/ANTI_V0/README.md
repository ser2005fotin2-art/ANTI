# ANTI V0

Inverse-pressure bonding curve prototype.

BUY increases curveSupply and lowers the marginal price.
SELL decreases curveSupply and raises the marginal price.

V0 intentionally accumulates growthReserve but does not yet use it to
reprice the curve. The reserve-backed growth mechanism comes after solvency
and invariant tests.

Use only for local/testnet experiments. Do not use real funds.
